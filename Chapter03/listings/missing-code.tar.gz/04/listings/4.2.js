$(() => {
  const $speech = $('div.speech');
  
  $('#switcher-large')
    .click((e) => {
      const num = parseFloat($speech.css('fontSize'));
    });
});
