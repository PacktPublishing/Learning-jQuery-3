$(() => {
  $('#switcher-large').on('click', function() {
    $('body').addClass('large');
  });
});
