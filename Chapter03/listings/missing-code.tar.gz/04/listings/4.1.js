$(() => {
  $('#switcher-large')
    .click((e) => {

    });
});
